/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Suhaani Gupta
 *
 * Created on July 1, 2022, 1:49 AM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
 
    // Declare Variables
  int num1; // Number 1
  int num2; // Number 2
  int total; // Sum of Number 1 and Number 2
  
  //Initialize Variables
  num1 = 50; 
  num2 = 100;
  
  // Map inputs to outputs -> The Process
  total = num1 + num2;
  //Display Results
  cout << total << endl;
  
    
    
    
    return 0;
}

